// DOM elements
const searchInput = document.querySelector("#searchInput");
const userList = document.querySelector("#userList");

// API URL
const apiUrl = "https://jsonplaceholder.typicode.com/users";

// Fetch API data
fetch(apiUrl)
  .then((response) => response.json())
  .then((data) => {
    // Create user cards
    const createCard = (user) => {
      const card = document.createElement("div");
      card.classList.add("card");
      card.innerHTML = `
        <img src="https://robohash.org/${user.username}.png" alt="User Avatar">
        <div>
          <p><strong>${user.name}</strong></p>
          <p>${user.company.name}</p>
          <p>${user.address.city}, ${user.address.country}</p>
          <p>Phone: ${user.phone}</p>
          <p>Email: ${user.email}</p>
          <a href="${user.website}" target="_blank">Website</a>
        </div>
      `;
      const listItem = document.createElement("li");
      listItem.appendChild(card);
      return listItem;
    };

    // Render user cards
    const renderCards = (users) => {
      userList.innerHTML = "";
      if (users.length > 0) {
        const list = document.createElement("ul");
        users.forEach((user) => {
          const listItem = createCard(user);
          list.appendChild(listItem);
        });
        userList.appendChild(list);
      } else {
        const message = document.createElement("p");
        message.textContent = "No users found.";
        userList.appendChild(message);
      }
    };

    // Filter users by name
    const filterUsers = (event) => {
      const searchText = event.target.value.toLowerCase();
      const filteredUsers = data.filter((user) =>
        user.name.toLowerCase().includes(searchText)
      );
      renderCards(filteredUsers);
    };

    // Add event listener to search input
    searchInput.addEventListener("input", filterUsers);

    // Render all users on page load
    renderCards(data);
  });
